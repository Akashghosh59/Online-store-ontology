from django.http import HttpResponse
from django.shortcuts import render
from .models import SPARQL_Model

# Create your views here.
def index1(request):
    return HttpResponse("My Store Application")

def item(request):
    results = SPARQL_Model().get_stores()
    items = SPARQL_Model().get_items()
    return render(request, 'home.html', {"results":results, "items":items})

def price(request):
    item = request.GET["item"]
    results = SPARQL_Model().get_prices(item)
    return render(request, 'store.html', {"results":results, "price":price})