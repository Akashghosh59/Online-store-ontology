from django.db import models

from SPARQLWrapper import SPARQLWrapper2

class SPARQL_Model:
    def get_stores(self):
        sparql = SPARQLWrapper2("http://localhost:3030/store/sparql")
        sparql.setQuery("""
            PREFIX store:<http://www.semanticweb.org/imaka/ontologies/2020/11/Store-ontology#>
            SELECT ?name ?link
            WHERE {
            ?x a store:store.
            ?x store:hasName ?name.
            ?x store:hasAddress ?link
            }""")
        return sparql.query().bindings

    def get_items(self):
        sparql = SPARQLWrapper2("http://localhost:3030/store/sparql")
        sparql.setQuery("""
        PREFIX store:<http://www.semanticweb.org/imaka/ontologies/2020/11/Store-ontology#>
        SELECT DISTINCT ?x 
        WHERE {
            ?x rdfs:subClassOf* store:Item.
            FILTER(?x !=store:Item)  
        }
        ORDER BY ASC (?x)
            """)
        return sparql.query().bindings

    def get_price(self, price):
        sparql = SPARQLWrapper2("http://localhost:3030/store/sparql")
        query =  """PREFIX store:<http://www.semanticweb.org/imaka/ontologies/2020/11/Store-ontology#>
        SELECT ?name ?cost
        WHERE {
            ?x a store:store.
            ?x store:hasPrice ?cost.
            ?x store:hasName ?name."""
        query += "?add store:item '"+price+"'. }"

        sparql.setQuery(query)

        return sparql.query().bindings

    def test_db_pedia(self):
        sparql = SPARQLWrapper2("http://dbpedia.org/sparql")
        sparql.setQuery("""
            PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
            SELECT ?label
            WHERE { <http://dbpedia.org/resource/Asturias> rdfs:label ?label }""")
        for result in sparql.query().bindings:
            print('%s: %s' % (result["label"].lang, result["label"].value))
